﻿namespace ToolSYS.Data
{
    public static class DbConnect
    {
        //College Network
        //public const String oradb = "Data Source = oracle/orcl; User Id = T00224345; Password = d4knmyt!4yGi;";

        //Local
        public const string Oradb = "Data Source = localhost/XE; User Id = sys; Password = oracle; DBA Privilege=SYSDBA;";

    }
}
