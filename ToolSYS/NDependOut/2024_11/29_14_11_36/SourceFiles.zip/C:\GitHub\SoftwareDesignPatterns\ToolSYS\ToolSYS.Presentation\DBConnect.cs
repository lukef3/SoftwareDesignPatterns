﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ToolSYS.Presentation
{
    public class DBConnect
    {
        //College Network
        //public const String oradb = "Data Source = oracle/orcl; User Id = T00224345; Password = d4knmyt!4yGi;";

        //Local
        public const String oradb =
            "Data Source = localhost/XE; User Id = sys; Password = oracle; DBA Privilege=SYSDBA;";
    }
}
