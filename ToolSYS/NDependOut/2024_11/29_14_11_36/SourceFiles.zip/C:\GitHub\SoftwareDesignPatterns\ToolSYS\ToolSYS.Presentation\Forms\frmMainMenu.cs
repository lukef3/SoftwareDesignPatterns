﻿using ToolSYS.Presentation.Nav;

namespace ToolSYS.Presentation.Forms
{
    public partial class FrmMainMenu : NavForm
    {
        public FrmMainMenu(INavigation navigation) : base (navigation)
        {
            InitializeComponent();
        }
    }
}
