﻿using ToolSYS.Presentation.Nav;

namespace ToolSYS.Presentation.Forms
{
    public partial class FrmViewRentals : NavForm
    {
        public FrmViewRentals(INavigation navigation) : base(navigation)
        {
            InitializeComponent();
        }
    }
}
